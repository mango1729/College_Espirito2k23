import SmoothScroll from './core.js';

export default SmoothScroll;